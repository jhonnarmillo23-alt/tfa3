
ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL DEFAULT NULL AFTER full_name;

ALTER TABLE users ADD UNIQUE KEY uq_users_username (username);
