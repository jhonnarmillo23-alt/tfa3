<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Users extends BaseController
{
    private const AVATAR_DIR   = FCPATH . 'uploads/avatars/';
    private const THUMB_SIZE   = 150; // px, square

    private function render(string $view, array $data = []): string
    {
        return view('templates/header')
            . view($view, $data)
            . view('templates/footer');
    }

    public function index(): string
    {
        $data['users'] = (new UserModel())->findAll();

        return $this->render('users/index', $data);
    }

    // GET /users/new
    public function new(): string
    {
        return $this->render('users/form', [
            'title'  => 'New User',
            'action' => base_url('users/create'),
            'user'   => [],
            'errors' => [],
        ]);
    }

    // POST /users/create
    public function create()
    {
        $rules = [
            'username'  => 'required|min_length[3]|max_length[50]|is_unique[users.username]',
            'full_name' => 'required|min_length[2]|max_length[100]',
        ];

        if (! $this->validate($rules)) {
            return $this->render('users/form', [
                'title'  => 'New User',
                'action' => base_url('users/create'),
                'user'   => [],
                'errors' => $this->validator->getErrors(),
            ]);
        }

        (new UserModel())->insert([
            'username'  => trim($this->request->getPost('username')),
            'full_name' => trim($this->request->getPost('full_name')),
        ]);

        return redirect()->to('/users')->with('message', 'User created.');
    }

    // GET /users/(:num)/edit
    public function edit(int $id): string
    {
        $user = (new UserModel())->find($id);

        if (! $user) {
            throw PageNotFoundException::forPageNotFound("User #{$id} not found.");
        }

        return $this->render('users/form', [
            'title'  => 'Edit User',
            'action' => base_url("users/{$id}/update"),
            'user'   => $user,
            'errors' => [],
            'avatar' => true,
        ]);
    }

    // POST /users/(:num)/update
    public function update(int $id)
    {
        $model = new UserModel();
        $user  = $model->find($id);

        if (! $user) {
            throw PageNotFoundException::forPageNotFound("User #{$id} not found.");
        }

        $rules = [
            // {id} is replaced with the current record's id so a user can keep their own username.
            'username'  => "required|min_length[3]|max_length[50]|is_unique[users.username,id,{$id}]",
            'full_name' => 'required|min_length[2]|max_length[100]',
        ];

        // Only validate the avatar if a file was actually chosen.
        $file      = $this->request->getFile('avatar');
        $hasAvatar = $file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE;

        if ($hasAvatar) {
            $rules['avatar'] = [
                'label' => 'Profile picture',
                'rules' => 'uploaded[avatar]'
                    . '|is_image[avatar]'
                    . '|mime_in[avatar,image/jpg,image/jpeg,image/png]'
                    . '|ext_in[avatar,jpg,jpeg,png]'
                    . '|max_size[avatar,2048]', // KB => 2MB
            ];
        }

        if (! $this->validate($rules)) {
            return $this->render('users/form', [
                'title'  => 'Edit User',
                'action' => base_url("users/{$id}/update"),
                'user'   => array_merge($user, $this->request->getPost()),
                'errors' => $this->validator->getErrors(),
                'avatar' => true,
            ]);
        }

        $data = [
            'username'  => trim($this->request->getPost('username')),
            'full_name' => trim($this->request->getPost('full_name')),
        ];

        if ($hasAvatar && $file->isValid() && ! $file->hasMoved()) {
            if (! is_dir(self::AVATAR_DIR)) {
                mkdir(self::AVATAR_DIR, 0755, true);
            }

            // Random server-generated name: never trust the client's filename.
            $newName = $file->getRandomName();
            $file->move(self::AVATAR_DIR, $newName);

            // Display-ready square thumbnail, overwrites the original-size copy.
            \Config\Services::image()
                ->withFile(self::AVATAR_DIR . $newName)
                ->fit(self::THUMB_SIZE, self::THUMB_SIZE, 'center')
                ->save(self::AVATAR_DIR . $newName);

            // Remove the previous avatar so the folder doesn't fill up with orphans.
            if (! empty($user['avatar']) && is_file(self::AVATAR_DIR . $user['avatar'])) {
                unlink(self::AVATAR_DIR . $user['avatar']);
            }

            $data['avatar'] = $newName; // filename only
        }

        $model->update($id, $data);

        return redirect()->to('/users')->with('message', 'User updated.');
    }
}
