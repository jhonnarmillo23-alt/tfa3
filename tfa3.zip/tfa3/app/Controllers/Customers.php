<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Customers extends BaseController
{
    private function rules(): array
    {
        return [
            'full_name' => 'required|min_length[2]|max_length[100]',
            'email'     => 'required|valid_email|max_length[150]',
            'phone'     => 'permit_empty|max_length[30]',
        ];
    }

    private function render(string $view, array $data = []): string
    {
        return view('templates/header')
            . view($view, $data)
            . view('templates/footer');
    }

    public function index(): string
    {
        $customerModel = new CustomerModel();

        $data['customers'] = $customerModel->findAll();

        return $this->render('customers/index', $data);
    }

    // GET /customers/new
    public function new(): string
    {
        return $this->render('customers/form', [
            'title'    => 'New Customer',
            'action'   => base_url('customers/create'),
            'customer' => [],
            'errors'   => [],
        ]);
    }

    // POST /customers/create
    public function create()
    {
        if (! $this->validate($this->rules())) {
            return $this->render('customers/form', [
                'title'    => 'New Customer',
                'action'   => base_url('customers/create'),
                'customer' => [],
                'errors'   => $this->validator->getErrors(),
            ]);
        }

        (new CustomerModel())->insert([
            'full_name' => trim($this->request->getPost('full_name')),
            'email'     => trim($this->request->getPost('email')),
            'phone'     => trim((string) $this->request->getPost('phone')),
        ]);

        return redirect()->to('/customers')->with('message', 'Customer created.');
    }

    // GET /customers/(:num)/edit
    public function edit(int $id): string
    {
        $customer = (new CustomerModel())->find($id);

        if (! $customer) {
            throw PageNotFoundException::forPageNotFound("Customer #{$id} not found.");
        }

        return $this->render('customers/form', [
            'title'    => 'Edit Customer',
            'action'   => base_url("customers/{$id}/update"),
            'customer' => $customer,
            'errors'   => [],
        ]);
    }

    // POST /customers/(:num)/update
    public function update(int $id)
    {
        $model    = new CustomerModel();
        $customer = $model->find($id);

        if (! $customer) {
            throw PageNotFoundException::forPageNotFound("Customer #{$id} not found.");
        }

        if (! $this->validate($this->rules())) {
            // Redisplay with errors; the submitted values override the stored ones.
            return $this->render('customers/form', [
                'title'    => 'Edit Customer',
                'action'   => base_url("customers/{$id}/update"),
                'customer' => array_merge($customer, $this->request->getPost()),
                'errors'   => $this->validator->getErrors(),
            ]);
        }

        $model->update($id, [
            'full_name' => trim($this->request->getPost('full_name')),
            'email'     => trim($this->request->getPost('email')),
            'phone'     => trim((string) $this->request->getPost('phone')),
        ]);

        return redirect()->to('/customers')->with('message', 'Customer updated.');
    }
}