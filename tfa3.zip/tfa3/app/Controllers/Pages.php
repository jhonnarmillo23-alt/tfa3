<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index(): string
    {
        return view('templates/header')
            . view('pages/landing')
            . view('templates/footer');
    }

    public function about(): string
    {
        return view('templates/header')
            . view('pages/about')
            . view('templates/footer');
    }
}
