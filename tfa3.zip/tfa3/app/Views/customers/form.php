<h1><?= esc($title) ?></h1>

<?php if (! empty($errors)): ?>
    <div class="alert alert-error">
        <strong>Please fix the following:</strong>
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?= esc($action, 'attr') ?>" method="post">
    <?= csrf_field() ?>

    <label for="full_name">Full Name *</label>
    <input type="text" id="full_name" name="full_name" value="<?= esc($customer['full_name'] ?? '', 'attr') ?>">

    <label for="email">Email *</label>
    <input type="text" id="email" name="email" value="<?= esc($customer['email'] ?? '', 'attr') ?>">

    <label for="phone">Phone</label>
    <input type="text" id="phone" name="phone" value="<?= esc($customer['phone'] ?? '', 'attr') ?>">

    <button type="submit">Save</button>
    <a href="<?= base_url('customers') ?>">Cancel</a>
</form>
