<h1>User Accounts</h1>

<p><a class="btn" href="<?= base_url('users/new') ?>">+ New User</a></p>

<?php if (!empty($users)): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Avatar</th>
                <th>Username</th>
                <th>Full Name</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($users as $user): ?>
                <?php
                    $img = (! empty($user['avatar']) && is_file(FCPATH . 'uploads/avatars/' . $user['avatar']))
                        ? 'uploads/avatars/' . $user['avatar']
                        : 'uploads/avatars/placeholder.svg';
                ?>
                <tr>
                    <td><?= esc($user['id']) ?></td>
                    <td><img class="avatar" src="<?= base_url($img) ?>" alt="Avatar of <?= esc($user['username'], 'attr') ?>"></td>
                    <td><?= esc($user['username']) ?></td>
                    <td><?= esc($user['full_name']) ?></td>
                    <td><a href="<?= base_url('users/' . $user['id'] . '/edit') ?>">Edit</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No users available.</p>
<?php endif; ?>
