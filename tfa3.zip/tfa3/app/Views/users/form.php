<h1><?= esc($title) ?></h1>

<?php if (! empty($errors)): ?>
    <div class="alert alert-error">
        <strong>Please fix the following:</strong>
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<?php // multipart/form-data is required for file inputs ?>
<form action="<?= esc($action, 'attr') ?>" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <label for="username">Username *</label>
    <input type="text" id="username" name="username" value="<?= esc($user['username'] ?? '', 'attr') ?>">

    <label for="full_name">Full Name *</label>
    <input type="text" id="full_name" name="full_name" value="<?= esc($user['full_name'] ?? '', 'attr') ?>">

    <?php if (! empty($avatar)): ?>
        <label for="avatar">Profile Picture (JPG or PNG, max 2MB)</label>
        <?php
            $current = ! empty($user['avatar']) ? 'uploads/avatars/' . $user['avatar'] : 'uploads/avatars/placeholder.svg';
        ?>
        <img class="avatar avatar-lg" src="<?= base_url($current) ?>" alt="Current avatar">
        <input type="file" id="avatar" name="avatar" accept="image/png,image/jpeg">
    <?php endif; ?>

    <button type="submit">Save</button>
    <a href="<?= base_url('users') ?>">Cancel</a>
</form>
