    </div>
    <footer>
        &copy; <?= date('Y') ?> My App
    </footer>
</body>
</html>
