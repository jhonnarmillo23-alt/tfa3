<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My App</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        nav { background: #1f2937; padding: 12px 20px; }
        nav a { color: #fff; text-decoration: none; margin-right: 12px; }
        .container { padding: 20px; }
        h1 { margin-top: 0; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input[type=text], input[type=file] { display: block; width: 100%; max-width: 420px; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button, .btn { background: #2563eb; color: #fff; border: 0; padding: 8px 14px; margin-top: 16px; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
        .alert { padding: 10px 14px; border-radius: 4px; margin-bottom: 16px; max-width: 420px; }
        .alert-error { background: #fee2e2; color: #991b1b; }
        .alert-success { background: #dcfce7; color: #166534; }
        .alert ul { margin: 6px 0 0 18px; padding: 0; }
        .avatar { width: 48px; height: 48px; border-radius: 50%; object-fit: cover; }
        .avatar-lg { width: 96px; height: 96px; display: block; margin: 8px 0; }
        footer { background: #f3f4f6; padding: 15px; text-align: center; margin-top: 20px; }
    </style>
</head>
<body>
    <nav>
    <a href="<?= base_url() ?>">Home</a>
    <a href="<?= base_url('about') ?>">About</a>
    <a href="<?= base_url('customers') ?>">Customer Accounts</a>
    <a href="<?= base_url('users') ?>">User Accounts</a>
    </nav>
    <div class="container">
    <?php if (session()->getFlashdata('message')): ?>
        <div class="alert alert-success"><?= esc(session()->getFlashdata('message')) ?></div>
    <?php endif; ?>
