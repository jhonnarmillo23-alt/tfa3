<h1>About Us</h1>
<p>This app demonstrates a simple CodeIgniter 4 route and view setup.</p>
