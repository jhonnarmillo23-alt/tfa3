<?php
namespace Config;

$routes = Services::routes();

$routes->setDefaultNamespace('App\\Controllers');
$routes->setDefaultController('Pages');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// Cleaned default welcome routes and custom routes
$routes->get('/', 'Pages::index');
$routes->get('/about', 'Pages::about');

// Customers (static "new" routes must come before the (:num) routes)
$routes->get('/customers', 'Customers::index');
$routes->get('/customers/new', 'Customers::new');
$routes->post('/customers/create', 'Customers::create');
$routes->get('/customers/(:num)/edit', 'Customers::edit/$1');
$routes->post('/customers/(:num)/update', 'Customers::update/$1');

// Users
$routes->get('/users', 'Users::index');
$routes->get('/users/new', 'Users::new');
$routes->post('/users/create', 'Users::create');
$routes->get('/users/(:num)/edit', 'Users::edit/$1');
$routes->post('/users/(:num)/update', 'Users::update/$1');
